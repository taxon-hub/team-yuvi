package com.example.sergeherkul.hellotoast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.scaledrone.chat.R;

public class emergency extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);
    }
}
